package selenium;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SelJTest {
    WebDriver wd = null;

    @Before
    public void init() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Downloads\\Selenium jars\\chromedriver.exe");
        wd = new ChromeDriver();
        wd.manage().window().maximize();
        wd.get("http://localhost:8083/webselenium/index.jsp");
    }

    @Test
    public void test1() {
        wd.findElement(By.name("user")).sendKeys("Raghava");
        wd.findElement(By.name("submit")).submit();
        WebDriverWait wait = new WebDriverWait(wd, 10);
        WebElement resultElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.name("h1")));
        String actualres = resultElement.getText();
        String expres = "data inserted successfully";
        assertEquals(expres, actualres);
    }

    @Test
    public void test2() {
        wd.findElement(By.name("user")).sendKeys("Lagisetty");
        wd.findElement(By.name("submit")).submit();
        WebDriverWait wait = new WebDriverWait(wd, 10);
        WebElement resultElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.name("h1")));
        String actualres = resultElement.getText();
        String expres = "data inserted successfully";
        assertEquals(expres, actualres);
    }

    @After
    public void deref() {
        if (wd != null) {
            wd.close();
        }
        wd = null;
    }
}
