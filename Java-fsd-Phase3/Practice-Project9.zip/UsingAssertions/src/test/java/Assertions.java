import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.*;

public class Assertions {

    @Test
    @DisplayName("assert Examples")
    public void assertTests() {

        assertTrue(4 > 0);
        assertFalse(5 < 1);
        assertEquals(5, 5);
        assertNotEquals(5, 6);
    }

}
