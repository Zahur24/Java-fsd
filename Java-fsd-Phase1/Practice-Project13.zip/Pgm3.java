package practice2;

public class Pgm3 
{
    public static void main(String[] args)
    {
        Counter counter = new Counter();

        
        Thread t1 = new Thread(new IncrementTask(counter));
        Thread t2 = new Thread(new IncrementTask(counter));

        t1.start();
        t2.start();

        try 
        {
            
            t1.join();
            t2.join();		// Waiting for both threads to finish execution
        } 
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }

        System.out.println("Final counter value: " + counter.getCount());
    }
}

class Counter 
{
    private int count = 0;

    // Synchronized method to increment the counter
    public synchronized void increment() 
    {
        count++;
    }

    // Method to get the counter value
    public int getCount()
    {
        return count;
    }
}

// Task to increment the counter
class IncrementTask implements Runnable
{
    private Counter count;

    public IncrementTask(Counter count) 
    {
        this.count = count;
    }

    @Override
    public void run()
    {
        for (int i = 0; i < 10; i++)
        {
            count.increment();
        }
    }
}
