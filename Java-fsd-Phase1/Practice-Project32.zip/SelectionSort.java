package practice4;
import java.util.Scanner;

public class SelectionSort {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the array: ");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter the array Elements");
		for(int i=0;i<n;i++) {
			a[i]=sc.nextInt();
		}
		System.out.print("Array before Sorting: ");
		printArray(a);
		selectionSort(a);
		System.out.print("\nSorted array using Selection Sort: ");
		printArray(a);
		sc.close();
	}
	public static void printArray(int[]arr) {
		for(int x:arr) {
			System.out.print(x+" ");
		}
	}
	public static void selectionSort(int x[])
	{
		for(int i=0;i<x.length;i++)
		{
			int indexValue = i;
			
			for(int j=i+1;j<x.length;j++)
			{
				if(x[j]<x[indexValue])
					indexValue = j;
			}
			
			int temp = x[indexValue];
			x[indexValue] = x[i];
			x[i] = temp;
		}
	}
}
