package practice3;

import java.util.Arrays;
import java.util.Scanner;

public class FourthSmallest {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		//	Example unsorted Array taken as [2,7,5,1,9,3,6] of size 7
		
		System.out.print("Enter the size of the Array (size>4) : ");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter the Elements of the Array: ");
		for(int i=0;i<n;i++) {
			a[i]=sc.nextInt();
		}
		System.out.println("Your unsorted array is "+Arrays.toString(a));
		//Sorting the unsorted Array using Arrays.sort
		
		Arrays.sort(a);
		
		//Fourth smallest element is
		
		System.out.println("\nFourth smallest element in the array is "+a[3]);
		sc.close();
	}
}
