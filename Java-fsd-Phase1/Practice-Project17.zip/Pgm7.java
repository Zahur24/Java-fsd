package practice2;

import java.io.*;
import java.util.Scanner;

public class Pgm7 {
    
    public static void createFile(String fileName)		// Method to create a new file
    {
        try {
            File f = new File(fileName);
            if (f.createNewFile()) 
            {
                System.out.println("File created: " + f.getName());
            } 
            else 
            {
                System.out.println("File already exists.");
            }
        }
        catch (IOException e) 
        {
            System.out.println("An error occurred while creating the file: " + e.getMessage());
        }
    }

    
    public static void readFile(String fileName) 
    {
        try {
            FileReader r = new FileReader(fileName);
            BufferedReader br = new BufferedReader(r);
            String line;
            System.out.println("File contents :");
            while ((line = br.readLine()) != null) 
            {
                System.out.println(line);
            }
            br.close();
        } 
        catch (IOException e) 
        {
            System.out.println("An error occurred while reading the file: " + e.getMessage());
        }
    }

    // Method to write or update content to a file
    public static void writeFile(String fileName, String data) 
    {
        try 
        {
            FileWriter fw = new FileWriter(fileName);
            BufferedWriter bufferedWriter = new BufferedWriter(fw);
            bufferedWriter.write(data);
            bufferedWriter.close();
            System.out.println("data has been added to the file.");
        } 
        catch (IOException e) 
        {
            System.out.println("An error occurred while writing to the file: " + e.getMessage());
        }
    }

    // Method to delete a file
    public static void deleteFile(String fileName)
    {
        File f = new File(fileName);
        
        if (f.delete()) 
        {
            System.out.println("File deleted: " + f.getName());
        } 
        else 
        {
            System.out.println("Failed to delete the file.");
        }
    }

    public static void main(String[] args) 
    {
    	Scanner sc = new Scanner(System.in);
    	System.out.println("Enter the name of the file: ");
        String fileName = sc.next();
        System.out.println("1.Create a new File\n2.Write data into the File\n3.Read and Display the data in File\n4.Update content in the File\n5.Delete the File ");
        int n=sc.nextInt();
        sc.nextLine();
        switch(n) {
        	case 1:
        		createFile(fileName);
        		break;
        	case 2:
        		System.out.println("Enter the data you want to Add to file: ");
        		String str=sc.nextLine();
        		 writeFile(fileName, str);
        		break;
        	case 3:
        		readFile(fileName);
        		break;
        	case 4:
        		System.out.println("Enter the data you want to update: ");
        		String s=sc.nextLine();
        		 System.out.print("Before update ");
        		 readFile(fileName);
        		 System.out.println("After updating  ");
        		 writeFile(fileName, s);
        		 readFile(fileName);
        		break;
        	case 5:
        		 deleteFile(fileName);
        		break;
        	default:
        		System.out.println("Invalid Input, Try again!!");
        }
        sc.close();
    }
}
