package practice2;

public class Pgm6 {			
	public static void main(String[] args) {
		try {							//try block contains the main code to be executed
			
			String str="Hi , I am learning Java Full Stack Development";	//custom made exception
			int len=length(str);
			System.out.println("Length of the String is "+len);
		}
		catch(Exception e) {			//catch block contains the code if certain exception occurs
			e.printStackTrace();
		}
		finally {			//Finally executes irrespective of the Exception occur
			System.out.println("The Program is Completed");
		}
	}
	public static int length(String str) throws Exception {
		int length =str.length();
		if (length>=20) {
			throw new Exception("Big String Exception");	//throw a custom exception with a message
		}
		return length;
	}
}


//Demonstrating Exception Handling with custom generated exception with condition String length should be below 20