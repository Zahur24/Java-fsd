package practice3;

public class CricularLinkedListExample 
{
	public static void main(String[] args) {
		CircularLinkedList cl = new CircularLinkedList();
		cl.addNode("Car");
		cl.addNode("Bus");
		cl.addNode("Bike");
		cl.addNode("Jeep");
		cl.addNode("Train");
		
		System.out.print("Original Circular Linked List : ");
		cl.TraverseValues();
		
		System.out.println("\n---------------------------------------------------------------------");
		
		cl.addNode("Ship");
		cl.addNode("Boat");
		System.out.print("Updated Circular Linked List : ");
		cl.TraverseValues();
	}
}

class CircularLinkedList {

			class Node
			{
				String  data;
				Node next;
				
				public Node(String data)
				{
					this.data = data;
					this.next = null;
				}
			}
			

			private Node head, tail = null;
			
			public void addNode(String data)
			{
				Node newNode = new Node(data);
				
				if(head==null)
				{
					head = newNode;
					tail = newNode;
					newNode.next = head;
					System.out.println("First Node Created....");
				}
				else
				{
					tail.next = newNode;
					tail = newNode;
					tail.next = head; // circular linkedlist
					System.out.println("Node Created...");
				}
			}
			
			public void TraverseValues()
			{
				Node getNode = head;
				if(head==null)
				{
					System.out.println("List is Empty");
				}
				else
				{
					do
					{
						System.out.print(getNode.data+" ");
						getNode = getNode.next;
					}
					while(getNode!=head);
				}
		}
}