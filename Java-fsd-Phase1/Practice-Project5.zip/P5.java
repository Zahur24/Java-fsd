package practice1;
import java.util.*;
import java.util.List;
import java.util.Set;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Vector;

public class P5 {
	
	public void collection_List() {
		//ArrayList
		
				List<String> i1 = new ArrayList<String>();
				i1.add("Cricket");
				i1.add("Snake and Ladder");
				i1.add("Chess");
				i1.add("Ludo");
				System.out.println("ArrayList : "+i1);
				
				//LinkedList
				
				List<Integer> i2 = new LinkedList<>();
				i2.add(24);
				i2.add(56);
				i2.add(18);
				i2.add(10);

				System.out.println("LinkedList : "+i2);
				
				
				//Vector
				
				List<String> i3  = new Vector<>();
				i3.add("Ram Charan");
				i3.add("NTR");
				i3.add("Ravi Teja");
				i3.add("Pavan");
				
				System.out.println("Vector : "+i3);
	}
	
	public void collection_Set() {
		//HashSet
		
		Set<Integer>  marks = new HashSet<>();
		marks.add(10);
		marks.add(15);
		marks.add(12);
		marks.add(8);
		marks.add(6);
		System.out.println("HashSet : "+marks);
		
		//LinkedHashSet
		Set<String> pets = new LinkedHashSet<>();
		pets.add("Dog");
		pets.add("Cat");
		pets.add("Mouse");
		pets.add("Pegion");
		pets.add("Parrot");
		pets.add(null);
		System.out.println("LinkedHashSet : "+pets);
	}

	public static void main(String[] args) {
		P5 obj = new P5();
		System.out.println("List in Collections are ");
		obj.collection_List();
		System.out.println("\nSet in Collections are ");
		obj.collection_Set();
		
	}

}
