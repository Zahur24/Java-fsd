package practice4;

public class InsertionSort {
	public static void main(String[] args) {
		int arr[]= {64,18,7,10,24,49,34,1};		//Predefined Array
		System.out.print("Array before Sorting: ");
		printArray(arr);
		int res[]=insertionSort(arr);
		System.out.print("\nSorted array using Insertion Sort: ");
		printArray(res);
	}
	public static void printArray(int[]arr) {	//Method to print array
		for(int x:arr) {
			System.out.print(x+" ");
		}
	}
	public static int[] insertionSort(int x[])
	{
		for(int i=1;i<x.length;i++)
		{
			int temp = x[i];
			int j = i-1;
			
			while(j>=0 && temp<=x[j])
			{
				x[j+1] = x[j];
				j--;
			}
			x[j+1] = temp;
		}
		return x;
	}
}
