package practice1;

public class P3 {
	public static int a=24;
	
	//Implementation of methods 8 ways	(static/non-static,with or without return-type & parameter)
	static void m1() {
		System.out.println("Method one called");
	}
	public static void m2(String name) {
		System.out.println("Method two called");
		System.out.println("name: "+name);
	}
	public static int m3() {
		System.out.println("Method three called");
		return a;
	}
	public static int m4(int b) {
		System.out.println("Method four called");
		return a+b;
	}
	public void m5() {
		System.out.println("Method five called");
	}
	public void m6(double d) {
		System.out.println("Method six called");
		System.out.println("Double Value is:"+d);
	}
	public boolean m7() {
		System.out.println("Method seven called");
		return false;
	}
	public char m8(long l) {
		System.out.println("Method Eight called");
		System.out.println("Long Value: "+l);
		return '@';
	}
	public int mul(int a,int b) {
		return a*b;
	}
	public int mul(int a,int b,int c) {
		return a*b*c;			//method overloading
	}
	public static void main(String[] args) {
		P3 obj = new P3();
		m1();
		m2("Kohli");
		System.out.println(m3());
		System.out.println(m4(10));
		obj.m5();
		obj.m6(24.18);
		System.out.println(obj.m7());
		System.out.println(obj.m8(101825l));
		
		System.out.println(obj.mul(10, 24));
		System.out.println(obj.mul(10,18,24));	//method over loading
	}

}
