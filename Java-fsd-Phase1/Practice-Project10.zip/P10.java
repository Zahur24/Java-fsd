package practice1;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class P10 {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String reg = "^[a-zA-Z0-9]+$";		//checking Alpha-Numeric only contains Alphabets or numbers or both

        
        System.out.print("Enter String : ");	//Enter input string
        String s = sc.next();

       
        Pattern p = Pattern.compile(reg);	 // Compiling the regular expression

        
        Matcher match = p.matcher(s);	//Matcher object perform matching operation

        
        if (match.matches()) 			//verifying
        {
            System.out.println("Input is Alpha-Numeric.");	//regular Expression matched
        } 
        else 
        {
            System.out.println("Input is not Alpha-Numeric.");	//regular not Expression matched
        }
        sc.close();
	}
}
