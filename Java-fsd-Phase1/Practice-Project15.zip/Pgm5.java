package practice2;
import java.util.*;
public class Pgm5 {
	public static void main(String[] args) {
		try {										//try block
			Scanner sc = new Scanner(System.in);
			System.out.print("Enter Your Weight:");
			int weight=sc.nextInt();
			Weight w = new Weight();
			w.setWeigth(weight);
			System.out.println("You have a normal weight of "+w.getWeight());
			sc.close();
		}
		catch(OverWeightException e) {			//catch block, Exception is handled
			
			e.printStackTrace();		//printing error message totally
		}
		finally {								//finally block executes whether exception raises or not
			System.out.println("The Program is Finished....");
		}
	}
}
class OverWeightException extends Exception{		//Custom Exception Created
	public OverWeightException(String msg)
	{
		super(msg);
	}
}

class Weight{
	private int weight;
	public void setWeigth(int weight) throws OverWeightException{		//throws keyword
		if(weight>90) {
			throw new OverWeightException("You are over weight, need to do workout!");	//throw the custom exception
		}
		else
		{
			this.weight=weight;
		}
	}
	public int getWeight() {
		return this.weight;
	}
}