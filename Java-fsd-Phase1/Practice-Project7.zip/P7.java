package practice1;

public class P7 {	//Main Class
	
	static class StaticInner{		//Static Inner Class
		public void display() {
			System.out.println("Static Inner Class Created");
		}
	}
	
	class NonStaticInner{		//Non-Static Inner Class
		public void display() {
			System.out.println("Non-Static Inner Class Created");
		}
	}
	
	 // Method with a local inner class
	public void method() {
		class LocalInner{		//Local Inner Class
			void display() {
				System.out.println("Local Inner Class Created");
			}
		}
		LocalInner obj3 = new LocalInner();
		obj3.display();
	}
	
	public static void main(String[] args) {
		P7 obj = new P7();
		
		P7.StaticInner obj1 = new P7.StaticInner();
		obj1.display();
		
		P7.NonStaticInner obj2 = obj.new NonStaticInner();
		obj2.display();
		
		obj.method();
		
		AnonymousInner obj4 = new AnonymousInner() {
			@Override
			public void show() {
				System.out.println("Anonymous Inner Class Created");
			}
		};
		
		obj4.show();
	}

}

abstract class AnonymousInner{	//AnonymousInner Class
	public abstract void show();
}
