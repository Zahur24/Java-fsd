package practice2;


class MyThread extends Thread 
{
public void run() 
{
   System.out.println("Thread created by extending Thread class");
}
}

class Run implements Runnable 
{
public void run() 
{
   System.out.println("Thread created by implementing runnable interface");
}
}

public class Pgm1 
{
public static void main(String[] args) 
{
   
   MyThread thread = new MyThread();
   thread.start();
   
   Run r = new Run();
   Thread th = new Thread(r);
   th.start();
}
}
