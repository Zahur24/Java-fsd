package practice3;

public class DoublyLinkedListEx {
	public static void main(String[] args) {
		DoublyLinkedList i = new DoublyLinkedList();
		int arr[]= {3,4,5,7,8,9,18,24};
		
		for(int x:arr) {
			i.addNode(x);
		}
		System.out.println("--------------------------------------");
		System.out.print("Original List:");
		for(int x:arr) {
			System.out.print(x+" ");
		}
		System.out.println("\n----------------------------------------");
		System.out.print("Traverse in Forward Direction: ");
		i.TraverseForward();
		
		System.out.println();
		System.out.print("Traverse in Backward Direction: ");
		i.TraverseBackward();
	}
	
	
}

class DoublyLinkedList {

	// node creation
	class Node
	{
		int data;
		Node prvs;
		Node next;
		
		public Node(int data)
		{
			this.data = data;
			this.prvs = null;
			this.next = null;
		}
	}
	
	private Node head, tail = null;
	
	public void addNode(int data)
	{
		Node newNode = new Node(data);
		
		if(head==null)
		{
			head = tail = newNode;  // data storing
			head.prvs =  null;
			head.next =  null;
			System.out.println("First Node is Created....");
		}
		else
		{
			// newNode will be added after tail such that tail's next will point to newNode
			tail.next = newNode;
			// newNode previous will point to the tail
			newNode.prvs = tail;
			// newNode becomes as tail
			tail = newNode;
			// next will be null
			tail.next = null;
			System.out.println("Node created...");
		}
	}
	
	public void TraverseForward()
	{
		Node getNode = head;
		if(head==null)
		{
			System.out.println("List is Empty");
		}
		else
		{
			while(getNode!=null)
			{
				System.out.print(getNode.data+" ");
				getNode = getNode.next;
			}
		}
	}
	
	public void TraverseBackward()
	{
		Node getNode = tail;
		if(tail==null)
		{
			System.out.println("List is Empty");
		}
		else
		{
			while(getNode!=null)
			{
				System.out.print(getNode.data+" ");
				getNode = getNode.prvs;
			}
		}
	}

}