package practice1;

public class P2 {
	
    public void publicMethod() {	
        System.out.println("This is a public method");	// Public can be accessible anywhere, have high level access
    }

    protected void protectedMethod() {						// Protected method accessible from subclasses and classes in the same package
        System.out.println("This is a protected method");
    }

    
    void defaultMethod() {
        System.out.println("This is a default method");		// Default method accessible only within the classes in the same package
    }

    
    private void privateMethod() {
        System.out.println("This is a private method");		// Private method accessible only from within the same class
    }

   
    public static void main(String[] args) {
        P2 obj = new P2();

        
        obj.publicMethod();
   
        obj.protectedMethod();

        obj.defaultMethod();

        obj.privateMethod();
        
    }
}
