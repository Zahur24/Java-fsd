package practice4;
import java.util.*;
public class BinarySearch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int arr[] = new int[] {24, 10, 28, 6, 7, 21, 14, 5};
        Arrays.sort(arr);
        System.out.print("Enter the Value to search: ");
        int n = sc.nextInt();
        binarySearch(arr, n);
        sc.close();
    }

    public static void binarySearch(int x[], int key) {
        int lb = 0, ub = x.length - 1;
        boolean flag = false;
        while (lb <= ub) {     // Always lower index should be less than or equal to upper index
            int mid = (ub + lb) / 2;
            if (x[mid] == key) {
                System.out.println("Value Found!");
                flag = true; // Update flag to true when value is found
                break;
            }
            if (x[mid] < key) {
                lb = mid + 1;
            } else {
                ub = mid - 1;
            }
        }
        if (!flag) {
            System.out.println("Value not found!");
        }
    }
}
