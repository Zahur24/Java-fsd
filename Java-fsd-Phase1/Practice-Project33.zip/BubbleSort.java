package practice4;

import java.util.*;
public class BubbleSort {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the array: ");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter the array Elements");
		for(int i=0;i<n;i++) {
			a[i]=sc.nextInt();
		}
		System.out.print("Array before Sorting: ");
		printArray(a);
		bubbleSort(a);
		System.out.print("\nArray after Sorting using Bubble Sort: ");
		printArray(a);
		sc.close();
		
	}
	public static void bubbleSort(int x[]) {
		int n=x.length;
		for(int i=0;i<n-1;i++) {
			for(int j=0;j<n-1;j++) {
				if(x[j+1]<x[j]) {
					int temp = x[j];
	                x[j] = x[j + 1];
	                x[j + 1] = temp;		//swapping
				}
			}
		}
	}
	public static void printArray(int[]arr) {
		for(int x:arr) {
			System.out.print(x+" ");
		}
	}
}
