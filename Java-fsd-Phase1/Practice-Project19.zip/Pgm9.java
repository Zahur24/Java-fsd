package practice2;


interface Animal {
 void eat();
}

interface Pet extends Animal {
 void play();
}

interface WildAnimal extends Animal {
 void run();
}

class Cat implements Pet, WildAnimal {
 @Override
 public void eat() {
     System.out.println("Cat is eating the Fish");
 }

 @Override
 public void play() {
     System.out.println("Cat is playing with a woolen ball");
 }

 @Override
 public void run() {
     System.out.println("Cat is Running in the House");
 }
}

public class Pgm9 {
 public static void main(String[] args) {
     
     Cat c = new Cat();
     
     c.eat(); 
     c.play(); 
     c.run(); 
 }
}
