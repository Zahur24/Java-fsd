package practice3;

import java.util.Stack;

public class StackEx {
    public static void main(String[] args) {
        
        Stack<Integer> stack = new Stack<>();		// Creating a stack
        
        stack.push(2);	// Adding elements to the stack
        stack.push(5);
        stack.push(6);
        stack.push(9);
        stack.push(10);
        stack.push(12);
        stack.push(13);

       
        System.out.println("Stack before operations: " + stack);		 // Print the stack
        
       
        System.out.println("Stack Size at first: " + stack.size());		 // Printing the size of the stack
        
        System.out.println("Top Element: " + stack.peek());	//peek method
        
        System.out.println("Popped Element: " + stack.pop());		//Deleting top

        System.out.println("updated Stack: " + stack);
        System.out.println("Popped Element: " + stack.pop());		//Deleting top
        System.out.println("Popped Element: " + stack.pop());		//Deleting top
        System.out.println("updated Stack: " + stack);
        

    }
}
