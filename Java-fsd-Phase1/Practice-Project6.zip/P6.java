package practice1;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class P6 {
	
	public static void main(String[] args) {
		
		//HashMap
		HashMap<Integer,String> i1 = new HashMap<>();
		i1.put(null,"Taj Mahal");
		i1.put(1, null);
		i1.put(2, "Charminar");
		i1.put(3, "Red Fort");
		i1.put(4, "Eiffel Tower");
		i1.put(5, "River Rose");
		System.out.println("Key and Values of HashMap are");
	      for(HashMap.Entry<Integer,String> n:i1.entrySet()){    
		       System.out.println(n.getKey()+" "+n.getValue());  
		      }
		
		//LinkedHashMap
		LinkedHashMap<String,Integer> i2 = new LinkedHashMap<>();
		i2.put("One", 24);
		i2.put("Two", null);
		i2.put("Three", 125);
		i2.put("Four", 18);
		i2.put("Five", 10);
		System.out.println("\nKey and Values of LinkedHashMap are");
		for(Map.Entry x: i2.entrySet()) {
			System.out.println(x.getKey()+"  "+x.getValue());
		}
		
		//HashTable
		
		Hashtable<Integer,Character> ht = new Hashtable<>();
		//System.out.println(ht.isEmpty());
		ht.put(56,'@');
		ht.put(15,'&');
		ht.put(25,'$');
		ht.put(18,'!');
		ht.put(10,'%');
		System.out.println("\nKey and Values of Hashtable are");
		for(Entry<Integer, Character> x: ht.entrySet()) {
			System.out.println(x.getKey()+"  "+x.getValue());
			
		}
		
		//TreeMap
		Map<Double,Boolean> tm = new TreeMap<>();
		tm.put(24.35, true);
		tm.put(125.21, true);
		tm.put(18.10, false);
		tm.put(10.24, false);
		tm.put(13.9, true);
		tm.put(24.18, false);
		System.out.println("\nKey and Values of TreeMap are");
		for(Map.Entry<Double,Boolean> x: tm.entrySet()) {
			System.out.println(x.getKey()+"  "+x.getValue());
		}
	}
}
