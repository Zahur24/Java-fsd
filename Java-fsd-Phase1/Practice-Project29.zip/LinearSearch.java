package practice4;

import java.util.*;

public class LinearSearch{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int a[]= {9,10,18,24,25,28,5,6};
		System.out.print("Original Array : ");
		for(int x:a) {
			System.out.print(x+" ");
		}
		
		System.out.print("\nEnter the Value to search : ");
		
		int n=sc.nextInt();
		linearSearch(a, n);
		sc.close();
		
	}
	
	public static void linearSearch(int x[],int key) {
		boolean b=false;
		for(int i=0;i<x.length;i++) {
			if(x[i]==key) {
				System.out.println("Value found !");
				b=true;
				break;
			}
		}
		if(b==false)
		{
			System.out.println("Value Not Found!!");
		}
	}
}
