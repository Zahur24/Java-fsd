package practice3;

import java.util.*;

public class QueueEx 
{
public static void main(String[] args) 
{
        		Queue<String> shape = new LinkedList<>();
        		shape.add("Cone");
        		shape.add("Triangle");
        		shape.add("square");
        		shape.add("Circle");
        		shape.add("Pentagon");
        		System.out.println("Original Queue is : " + shape);
        		System.out.println("Top of Queue : " + shape.peek());
        		shape.remove();
        		System.out.println("After removing Top of Queue : " + shape);
        		System.out.println("Size of Queue : " + shape.size());
        		shape.remove();
        		System.out.println("After removing Top of Queue : " + shape);
        		System.out.println("Size of Queue : " + shape.size());
    	}
}

