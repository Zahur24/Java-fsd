package practice4;
import java.util.*;
public class QuickSort{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the size of the array: ");
		int n=sc.nextInt();
		System.out.println("Enter the array elements: ");
		int arr[] = new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i] = sc.nextInt();	//Enter the elements
		}
		System.out.print("Before QuickSort : ");
		display(arr);
		quickSort(arr,0,arr.length-1);	//Array,left index, right index
		System.out.print("After QuickSort : ");
		display(arr);
		sc.close();
	}
	public static void display(int a[]) {
		for(int x:a) {
			System.out.print(x+" ");
		}
		System.out.println();
	}
	public static int partition(int arr[],int leftt,int right)
	{
		int pivot = arr[leftt];
		int start = leftt;
		int end = right;
		while(start<end)
		{
			start=start+1;
			while(start<=right && arr[start]<pivot)
			{
				start++;
			}
			while(end>=leftt && arr[end]>pivot)
			{
				end--;
			}
			if(start<end)
			{
				int temp=arr[start];
				arr[start]=arr[end];
				arr[end]=temp;
			}
		}
		int temp=arr[leftt];
		arr[leftt]=arr[end];
		arr[end]=temp;
		return end;
	}
	public static void quickSort(int arr[],int leftt,int right)
	{
		int p;
		if(leftt<right)
		{
			p=partition(arr,leftt,right);
			quickSort(arr,leftt,p-1);
			quickSort(arr,p+1,right);
		}
	}
}
