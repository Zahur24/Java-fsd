package practice1;

public class P1 {
	
	public static void main(String[] args) {
		//Implicit type casting 	(JVM) changes it automatically
		
		int a=25;
		
		double d=a;
		
		System.out.println(d);	//Automatically changes from int to double

		//Explicit Type casting
		
		double db = 55.25;
		
		int b= (int) db;
		
		System.out.println(b);	//Manually changing from double to int
	}
}
