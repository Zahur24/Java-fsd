package practice2;

public class Pgm8 extends PolymorphismExample {
	
	public void rcb() {
		super.ipl();
		System.out.println("His Highest score in ipl is "+super.score+" runs.");
	}
	
	public void sum(int a,int b,int c) {
		System.out.println("Overrided method");
		System.out.println("Sum is "+(a+b+c));	//Method Overriding		//Run time Polymorphism
		super.sum(a, b, c);
		super.sum(a, b);
		
	
	}
	
	public static void main(String[] args) {
		
		//Encapsulation Example
		EncapsulationExample encapsulate = new EncapsulationExample("Kohli", 38);
		System.out.println("Name: "+encapsulate.getName()+"\tAge: "+encapsulate.getAge());
		
		//Abstraction Example
		AbstractionExample ab = new Pgm8();		//object casting
		ab.passion();
		
		//Inheritance Example
		Pgm8 i = new Pgm8();
		i.rcb();
		
		//Polymorphism Example
		System.out.println("----------------------Polymorphism------------------------");
		Pgm8 p = new Pgm8();
		p.sum(10, 18, 24);
		
		
		
	}
}

class EncapsulationExample{
	private String name;
	private int age;
	
	public EncapsulationExample(String name, int age) {
		this.name = name;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
}

abstract class AbstractionExample{
	abstract void passion();
}

class InheritanceExample extends AbstractionExample{
	int score=973;
	
	public void passion() {		//Abstraction by overriding abstract methods of abstract class
		System.out.println("Kohli plays cricket for Indain Cricket team.");
	}
	
	public void ipl() {
		System.out.println("He also plays for the RCB in the IPL.");
	}
}

class PolymorphismExample extends InheritanceExample{
	public void sum(int a,int b){
		System.out.println("Method in PolymorphismExample class");
		System.out.println("sum is "+(a+b));	
	}
	public void sum(int a,int b,int c) {
		System.out.println("Method in PolymorphismExample class and over loaded method");
		System.out.println("sum is "+(a+b+c));		//Method Overloading		//compile time Polymorphism
		
	}
}