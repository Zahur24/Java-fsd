package practice3;
import java.util.Scanner;

public class Sum 
{
    public static void main(String[] args) 
    {
        int[] array = new int[] {1,2,4,5,7,9,10,18,24}; // Predefined array
        Scanner sc=new Scanner(System.in);
        
        System.out.print("Enter the Starting index:");
        int L =sc.nextInt(); //first index
        
        System.out.print("Enter the Ending index:");
        int R = sc.nextInt(); // last index
        int n = array.length; // Length of the array

        if (L < 0 || R >= n || L > R) 	//condition for invalid ranges
        {
            System.out.println("Invalid range!");
            System.exit(0);
        }
        // calculating sum
        int sum = 0;
        for (int i = L; i <= R; i++) 
        {
            sum =sum+array[i];
        }

        System.out.println("Sum of elements from index " + L + " to " + R + " is " + sum);
        sc.close();
    }
}
