package practice1;

public class P4 {
	public long number = 123456789l;
	
	public String empName;
	public int empId;
	
	//Default constructor
	public P4(){
		System.out.println("Default Constructor called");
	}
	
	//Parameterized Constructor
	public P4(String name) {
		System.out.println("Parameterized Constructor called");
		System.out.println("Name is "+name);
	}
	
	//Object Parameterized Constructor
	public P4(P4 x) {
		System.out.println("Parameterized Constructor called");
		System.out.println(x.number);;
	}
	
	public P4(String empName,int empId) {
		this.empName=empName;
		this.empId=empId;
	}
	public void display() {
		System.out.println("Name: "+this.empName+"   Id: "+empId);
	}
	public static void main(String[] args) {
		P4 obj = new P4();
		new P4("king");
		new P4(obj);
		
		P4 i1=new P4("Vicky",255699);
		P4 i2=new P4("Ronaldo",456987);
		i1.display();
		i2.display();
	}
}
