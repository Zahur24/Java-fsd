package practice2;

public class Pgm4 {
	
	public static void main(String[] args) {
		try {
			int a = 50, b = 10, c = 0;
			
			// Performing normal division operation
			
			int div1 = a / b;
			System.out.println("Division of " + a + " by " + b + " is " + div1);
			
			//Performing Division with Zero
			int div2 = a / c; // This line will throw an ArithmeticException as division with Zero not possible
			System.out.println("Division of " + a + " by " + c + " is " + div2); // This line will not be executed
		
		} 
		catch (ArithmeticException e) 			// Catching the ArithmeticException
		{ 
			
			System.out.println("\nDivision by zero is not allowed.");
		}
	}
}
