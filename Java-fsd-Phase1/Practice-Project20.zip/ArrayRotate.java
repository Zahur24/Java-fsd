package practice3;

public class ArrayRotate {
	public static void print(int x[]) {
		for(int z:x) {
			System.out.print(z+" ");
		}
	}
	public static void main(String[] args) {
		int x[]=new int[] {1,2,3,4,5,6,7,8};
		int steps = 5,n=x.length;
		System.out.print("Array before rotating: ");
		print(x);
	
		for(int i=1;i<=5;i++) {
			int last = x[n-1];
			for(int j=0;j<n-1;j++) {
				x[j+1]=x[j];
			}
			x[0]=last;
			}
		
		System.out.print("\nArray after rotating "+steps+" steps: ");
		print(x);

	}

}
