package practice1;

public class P9 {
	public static void main(String[] args) {
		//single Dimensional Array
				int a[] = new int[5];
				a[0]=24;
				a[1]=15;
				a[2]=18;
				a[3]=10;
				a[4]=29;
				System.out.println("Single Dimentional Array:  ");
				for(int x:a) {
					System.out.print(x+" ");
				}
				
				//Multi-Dimentional Array
				int m[][]= {
						{10,18,24},
						{15,20,29},
						{19,27,32}
				};
				System.out.println("\nLenght of multi Dimentional Array is: "+m.length);
				for(int i=0;i<3;i++) {
					for(int j=0;j<3;j++) {
						System.out.print(m[i][j]+" ");
					}
					System.out.println();
				}
	}
}
