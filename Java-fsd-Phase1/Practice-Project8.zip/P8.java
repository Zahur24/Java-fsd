package practice1;
public class P8 {

	public static void main(String[] args) {
		String s = "Hello World!, I'm learning Java";
		System.out.println(s);//String creating
		System.out.println(s.length());
		System.out.println(s.isEmpty());
		System.out.println(s.substring(0, 12));
		
		//Creating StringBuffer
		
		StringBuffer sBuffer = new StringBuffer(s);	//StringBuffer from String
		System.out.println(sBuffer.reverse());
		
		//Creating String Builder
		StringBuilder sBuilder = new StringBuilder(s);	//StringBuilder from String
		sBuilder.replace(13, 31, "Welcome to E-learning");
		System.out.println(sBuilder);
		sBuilder.append(" Course");
		System.out.println(sBuilder);

	}

}
