package practice4;
import java.util.Scanner;
public class ExponentialSearch {
    public static int exponentialSearch(int[] arr, int target) {
        if (arr[0] == target) {
            return 0;
        }
        int i = 1;
        // Find the range for binary search by repeated doubling
        while (i < arr.length && arr[i] <= target) {
            i *= 2;
        }
        // Perform binary search in the found range
        return binarySearch(arr, target, i / 2, Math.min(i, arr.length - 1));
    }

    public static int binarySearch(int[] arr, int target, int left, int right) {
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (arr[mid] == target) {
                return mid;
            }
            if (arr[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1; // If the target is not found
    }

    public static void main(String[] args) {
        int[] arr = {2, 6, 8, 10, 15, 18, 36, 74};
        int target;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the value to search: ");
        target = sc.nextInt();
        int result = exponentialSearch(arr, target);
        if (result == -1) {
            System.out.println("Value not Found!");
        } else {
            System.out.println("Value found at index " + result + ".");
        }
        sc.close();
    }
}
